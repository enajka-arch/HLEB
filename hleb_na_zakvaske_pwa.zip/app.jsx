
const { useEffect, useMemo, useState } = React;

// helpers
const LSK = { SETTINGS:'doughtrack_settings_v1', BATCHES:'doughtrack_batches_v1', STARTER:'doughtrack_starter_v1' };
const nowIso = () => new Date().toISOString();
const inHours = (ms) => ms/3_600_000;
const loadLS = (k,f)=>{ try{const r=localStorage.getItem(k); return r?JSON.parse(r):f;}catch{return f;}};
const saveLS = (k,v)=>{ try{localStorage.setItem(k, JSON.stringify(v));}catch{} };
const q10Eta = (h,t0,t)=> h/Math.pow(2,(t - t0)/10);
const pretty = (dt)=> new Date(dt).toLocaleString([], {hour:'2-digit',minute:'2-digit',day:'2-digit',month:'short'});
const dur = (ms)=>{ if(ms==null)return '—'; const n=ms<0; ms=Math.abs(ms); const h=Math.floor(ms/3_600_000), m=Math.floor(ms%3_600_000/60_000); return `${n?'-':''}${h}ч ${String(m).padStart(2,'0')}м`; };

const defaultSettings = { units:'metric', defaultTempC:24 };
const defaultStarter = { name:'Закваска', hydration:100, lastFeedAt:null, peakWindow_h:4 };

function useStore(){
  const [settings,setSettings]=useState(()=>loadLS(LSK.SETTINGS, defaultSettings));
  const [batches,setBatches]=useState(()=>loadLS(LSK.BATCHES, []));
  const [starter,setStarter]=useState(()=>loadLS(LSK.STARTER, defaultStarter));
  useEffect(()=>saveLS(LSK.SETTINGS, settings),[settings]);
  useEffect(()=>saveLS(LSK.BATCHES, batches),[batches]);
  useEffect(()=>saveLS(LSK.STARTER, starter),[starter]);
  return {settings,setSettings,batches,setBatches,starter,setStarter};
}

function App(){
  const {settings,setSettings,batches,setBatches,starter,setStarter}=useStore();
  const [tab,setTab]=useState('home');
  const active = useMemo(()=>batches.find(b=>b.status==='active'),[batches]);
  useEffect(()=>{ document.title='Хлеб на закваске — трекер'; },[]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-rose-50 dark:from-zinc-950 dark:to-black text-zinc-900 dark:text-zinc-100">
      <div className="max-w-3xl mx-auto p-4 pb-24">
        <header className="sticky top-0 z-10 -mx-4 px-4 py-3 bg-gradient-to-b from-amber-50/90 to-rose-50/60 dark:from-zinc-950/90 dark:to-black/60 backdrop-blur border-b border-zinc-200/60 dark:border-zinc-800/60">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">🍞 Хлеб на закваске</h1>
            <nav className="flex gap-2">
              {['home','new','starter','settings'].map(id=>(
                <button key={id} onClick={()=>setTab(id)} className={`px-3 py-1.5 rounded-full text-sm border ${tab===id?'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 border-transparent':'bg-white/60 dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800'}`}>{({'home':'Домой','new':'Новая партия','starter':'Закваска','settings':'Настройки'})[id]}</button>
              ))}
            </nav>
          </div>
        </header>
        <main className="mt-4 space-y-4">
          {tab==='home' && <Home active={active} batches={batches} setBatches={setBatches}/>}
          {tab==='new' && <NewBatch settings={settings} onCreate={(b)=>setBatches([b,...batches])}/>}
          {tab==='starter' && <Starter starter={starter} setStarter={setStarter}/>}
          {tab==='settings' && <Settings settings={settings} setSettings={setSettings}/>}
        </main>
      </div>
      <footer className="fixed bottom-0 inset-x-0 p-3 text-center text-xs text-zinc-500 bg-gradient-to-t from-white/80 to-transparent dark:from-black/60">Офлайн-хранилище · v0.1</footer>
    </div>
  );
}

function Home({active,batches,setBatches}){
  const [tick,setTick]=useState(0);
  useEffect(()=>{ const id=setInterval(()=>setTick(t=>t+1),1000); return ()=>clearInterval(id);},[]);
  const now = Date.now();

  const finishAt = useMemo(()=>{
    if(!active) return null;
    const etaH = q10Eta(Number(active.baseTime_h), Number(active.baseTempC), Number(active.currentTempC));
    if(!etaH) return null;
    let refined = etaH;
    if(active.riseLogs?.length>=2){
      const logs=[...active.riseLogs].sort((a,b)=>new Date(a.at)-new Date(b.at));
      const t0=new Date(logs[0].at).getTime(), t1=new Date(logs.at(-1).at).getTime();
      const p0=logs[0].pct, p1=logs.at(-1).pct;
      const dp=Math.max(1, p1-p0), dt=(t1-t0)/3_600_000;
      const rate=dp/dt, remaining=Math.max(0, Number(active.targetRise_pct)-p1);
      refined = dt + (remaining/rate);
    }
    return new Date(new Date(active.startedAt).getTime() + refined*3_600_000).getTime();
  },[active]);

  function updateActive(patch){ setBatches(prev=>prev.map(b=>b.id===active.id?{...b,...patch}:b)); }
  function markDone(id){ setBatches(prev=>prev.map(b=>b.id===id?{...b,status:'done'}:b)); }
  function deleteBatch(id){ setBatches(prev=>prev.filter(b=>b.id!==id)); }

  const nextFoldEveryMin = 30;
  const nextAction = useMemo(()=>{
    if(!active||!finishAt) return null;
    const total=finishAt - new Date(active.startedAt).getTime();
    const elapsed=now - new Date(active.startedAt).getTime();
    const half=total/2;
    if(elapsed<half){
      const sinceLast=active.lastFoldAt? (now - new Date(active.lastFoldAt).getTime()) : Infinity;
      const dueIn=Math.max(0, nextFoldEveryMin*60_000 - sinceLast);
      return { label: dueIn===0?'Сложить сейчас':`Сложить через ${Math.round(dueIn/60_000)} мин`, at: now+dueIn, type:'fold' };
    }
    return { label:'Ждём целевого подъёма', at: finishAt, type:'target' };
  },[active,finishAt,now]);

  return (
    <div className="space-y-4">
      {!active ? (
        <Section title="Нет активной партии">
          <p className="text-sm text-zinc-600 dark:text-zinc-400">Создайте новую партию на вкладке «Новая партия». Я подержу миску морально.</p>
          <div className="mt-3">
            {batches.length>0 && (
              <>
                <div className="text-xs uppercase tracking-wide text-zinc-500 mb-2">Завершённые</div>
                <div className="grid gap-2">
                  {batches.filter(b=>b.status!=='active').map(b=>(
                    <div key={b.id} className="p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white/60 dark:bg-zinc-900/60 flex items-center justify-between">
                      <div>
                        <div className="font-medium">{b.name||`Партия ${b.id}`}</div>
                        <div className="text-xs text-zinc-500">Старт: {pretty(b.startedAt)} · Цель: {b.targetRise_pct}%</div>
                      </div>
                      <button onClick={()=>deleteBatch(b.id)} className="text-xs px-2 py-1 border rounded-lg">Удалить</button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </Section>
      ) : (
        <Section title={active.name||'Активная партия'} right={
          <div className="flex gap-2">
            <button onClick={()=>updateActive({status:'paused'})} className="text-xs px-2 py-1 border rounded-lg">Пауза</button>
            <button onClick={()=>markDone(active.id)} className="text-xs px-2 py-1 border rounded-lg">Готово</button>
          </div>
        }>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Stat label="Старт" value={pretty(active.startedAt)} />
            <Stat label="Температура" value={`${active.currentTempC} °C`} hint={`База ${active.baseTempC} °C`} />
            <Stat label="Цель подъёма" value={`${active.targetRise_pct}%`} hint={`База ${active.baseTime_h} ч`} />
            <Stat label="Осталось" value={finishAt? dur(finishAt - Date.now()) : '—'} hint={finishAt? `ETA: ${pretty(finishAt)}` : ''} />
          </div>
          <div className="mt-4 p-3 rounded-xl bg-amber-100/70 dark:bg-amber-900/30 border border-amber-300/60 dark:border-amber-800/60">
            <div className="text-sm font-medium">{nextAction?.label||'—'}</div>
            {nextAction && <div className="text-xs text-zinc-600 dark:text-zinc-400">до {new Date(nextAction.at).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>}
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="p-3 rounded-xl border bg-white/60 dark:bg-zinc-900/60">
              <div className="text-sm font-semibold mb-2">Отметить подъём</div>
              <RiseLogger active={active} update={(patch)=>setBatches(prev=>prev.map(b=>b.id===active.id?{...b,...patch}:b))} />
            </div>
            <div className="p-3 rounded-xl border bg-white/60 dark:bg-zinc-900/60">
              <div className="text-sm font-semibold mb-2">Действия</div>
              <div className="flex flex-wrap gap-2">
                <button onClick={()=>setBatches(prev=>prev.map(b=>b.id===active.id?{...b,lastFoldAt:nowIso()}:b))} className="px-3 py-1.5 border rounded-lg text-sm">Сложил(а)</button>
                <button onClick={()=>setBatches(prev=>prev.map(b=>b.id===active.id?{...b,currentTempC:Number(b.currentTempC)+1}:b))} className="px-3 py-1.5 border rounded-lg text-sm">+1 °C</button>
                <button onClick={()=>setBatches(prev=>prev.map(b=>b.id===active.id?{...b,currentTempC:Number(b.currentTempC)-1}:b))} className="px-3 py-1.5 border rounded-lg text-sm">-1 °C</button>
              </div>
            </div>
          </div>
        </Section>
      )}
    </div>
  );
}

function RiseLogger({active, update}){
  const [pct,setPct]=useState(50);
  return (
    <div>
      <label className="text-xs text-zinc-500">Процент подъёма</label>
      <input type="range" min={0} max={200} value={pct} onChange={e=>setPct(Number(e.target.value))} className="w-full" />
      <div className="flex items-center justify-between text-sm mb-2"><span>0%</span><span>{pct}%</span><span>200%</span></div>
      <button onClick={()=>{
        const log={at: nowIso(), pct:Number(pct)};
        const prev=active.riseLogs||[];
        update({ riseLogs:[...prev, log] });
      }} className="px-3 py-1.5 border rounded-lg text-sm">Добавить отметку</button>
    </div>
  );
}

function NewBatch({settings,onCreate}){
  const [form,setForm]=useState({ name:'Партия', flour_g:500, water_g:350, salt_g:10, starter_g:100, baseTempC:settings.defaultTempC||24, baseTime_h:6, currentTempC:settings.defaultTempC||24, targetRise_pct:90, vesselVolume_ml:2000 });
  const etaH = q10Eta(Number(form.baseTime_h), Number(form.baseTempC), Number(form.currentTempC));
  function setField(k,v){ setForm(p=>({...p,[k]:v})); }
  function submit(e){
    e.preventDefault();
    const id=Math.random().toString(36).slice(2,8);
    const batch={ id, name:form.name, startedAt:nowIso(), ...form, riseLogs:[], status:'active', notes:'' };
    onCreate(batch);
  }
  return (
    <Section title="Новая партия">
      <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
        <Field label="Название"><input className="w-full px-3 py-2 border rounded-xl" value={form.name} onChange={e=>setField('name', e.target.value)} /></Field>
        <Field label="Температура базовая (°C)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.baseTempC} onChange={e=>setField('baseTempC', Number(e.target.value))} /></Field>
        <Field label="Время при базовой T (ч)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.baseTime_h} onChange={e=>setField('baseTime_h', Number(e.target.value))} /></Field>
        <Field label="Текущая температура (°C)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.currentTempC} onChange={e=>setField('currentTempC', Number(e.target.value))} /></Field>
        <Field label="Целевой подъём (%)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.targetRise_pct} onChange={e=>setField('targetRise_pct', Number(e.target.value))} /></Field>
        <Field label="Ёмкость (мл)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.vesselVolume_ml} onChange={e=>setField('vesselVolume_ml', Number(e.target.value))} /></Field>
        <Field label="Мука (г)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.flour_g} onChange={e=>setField('flour_g', Number(e.target.value))} /></Field>
        <Field label="Вода (г)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.water_g} onChange={e=>setField('water_g', Number(e.target.value))} /></Field>
        <Field label="Соль (г)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.salt_g} onChange={e=>setField('salt_g', Number(e.target.value))} /></Field>
        <Field label="Закваска (г)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={form.starter_g} onChange={e=>setField('starter_g', Number(e.target.value))} /></Field>
        <div className="sm:col-span-2 mt-2 p-3 rounded-xl border bg-white/60 dark:bg-zinc-900/60">
          <div className="text-sm">Прогноз при {form.currentTempC} °C: <b>{etaH? `${etaH.toFixed(1)} ч` : '—'}</b> до целевого подъёма</div>
        </div>
        <div className="sm:col-span-2 flex gap-2 mt-2">
          <button className="px-4 py-2 rounded-xl border bg-zinc-900 text-white dark:bg-white dark:text-zinc-900">Старт!</button>
        </div>
      </form>
    </Section>
  );
}

function Starter({starter,setStarter}){
  const [feed,setFeed]=useState(50);
  const nextPeak = useMemo(()=> starter.lastFeedAt ? new Date(new Date(starter.lastFeedAt).getTime()+starter.peakWindow_h*3_600_000): null, [starter]);
  return (
    <div className="space-y-3">
      <Section title="Мой стартер">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Stat label="Название" value={starter.name} />
          <Stat label="Гидратация" value={`${starter.hydration}%`} />
          <Stat label="Пик активности" value={`${starter.peakWindow_h} ч`} />
          <Stat label="Последняя подкормка" value={starter.lastFeedAt? pretty(starter.lastFeedAt) : '—'} hint={nextPeak? `Пик ~ ${pretty(nextPeak)}`: ''} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 items-end">
          <Field label="Гидратация (%)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={starter.hydration} onChange={e=>setStarter({...starter, hydration:Number(e.target.value)})}/></Field>
          <Field label="Окно пика (ч)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={starter.peakWindow_h} onChange={e=>setStarter({...starter, peakWindow_h:Number(e.target.value)})}/></Field>
          <Field label="Количество подкормки (г)"><input type="number" className="w-full px-3 py-2 border rounded-xl" value={feed} onChange={e=>setFeed(Number(e.target.value))}/></Field>
          <button onClick={()=>{ setStarter({...starter, lastFeedAt: nowIso()}); }} className="px-4 py-2 rounded-xl border bg-zinc-900 text-white dark:bg-white dark:text-zinc-900">Подкормил(а)</button>
        </div>
      </Section>
    </div>
  );
}

function Settings({settings,setSettings}){
  return (
    <Section title="Настройки">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Единицы">
          <select className="w-full px-3 py-2 border rounded-xl" value={settings.units} onChange={e=>setSettings({...settings, units:e.target.value})}>
            <option value="metric">Метрические</option>
            <option value="imperial">Имперские</option>
          </select>
        </Field>
        <Field label="Температура по умолчанию (°C)">
          <input type="number" className="w-full px-3 py-2 border rounded-xl" value={settings.defaultTempC} onChange={e=>setSettings({...settings, defaultTempC:Number(e.target.value)})} />
        </Field>
      </div>
      <div className="mt-3 text-xs text-zinc-500">Данные хранятся только на устройстве (localStorage). Можно смело месить и офлайн.</div>
    </Section>
  );
}

function Section({title,children,right}){
  return (
    <div className="rounded-2xl shadow p-4 bg-white/70 dark:bg-zinc-900/60 backdrop-blur border border-zinc-200 dark:border-zinc-800">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">{title}</h2>
        {right}
      </div>
      {children}
    </div>
  );
}
function Stat({label,value,hint}){
  return (<div className="flex-1 min-w-[120px]"><div className="text-xs text-zinc-500 mb-1">{label}</div><div className="text-xl font-semibold">{value}</div>{hint && <div className="text-xs text-zinc-500 mt-1">{hint}</div>}</div>);
}
function Field({label,children}){ return (<label className="block text-sm"><div className="mb-1 text-xs text-zinc-500">{label}</div>{children}</label>); }

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
